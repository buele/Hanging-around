//
//  BueleButton.h
//  002-TableView_todolist
//
//  Created by Raffaele Bua on 21/02/14.
//

#import <UIKit/UIKit.h>

@interface BueleButton : UIButton{
    
}
- (id)initWithFrame:(CGRect)frame  andLabel:(NSString *)label;
@end