//
//  RemoveButton.m
//  BueleTableView
//
//  Created by Raffaele Bua on 16/03/14.
//
//

#import "RemoveButton.h"

@implementation RemoveButton
@synthesize indexPath;


@end
