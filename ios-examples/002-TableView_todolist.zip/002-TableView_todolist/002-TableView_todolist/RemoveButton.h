//
//  RemoveButton.h
//  BueleTableView
//
//  Created by Raffaele Bua on 16/03/14.
//
//

#import "BueleButton.h"

@interface RemoveButton : BueleButton

@property (nonatomic, retain) NSIndexPath * indexPath;

@end
