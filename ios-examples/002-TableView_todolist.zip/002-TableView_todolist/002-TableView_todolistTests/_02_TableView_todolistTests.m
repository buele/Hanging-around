//
//  _02_TableView_todolistTests.m
//  002-TableView_todolistTests
//
//  Created by Raffaele Bua on 18/03/14.
//  Copyright (c) 2014 Buele. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _02_TableView_todolistTests : XCTestCase

@end

@implementation _02_TableView_todolistTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
